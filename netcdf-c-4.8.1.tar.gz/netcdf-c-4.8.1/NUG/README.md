# README

## October 6, 2020

The NUG contents have been moved to the netCDF NUG repository found at:

* https://github.com/Unidata/netcdf

Please refer to this location for the NUG documentation.  Any changes to the documentation should have an issue opened in the NUG Github project and a corresponding PR opened.
